<?php

$email_to = "tiberiu.andrisan@mri.tum.de"; // your email address
$email_subject = "[SB Feedback Form]"; // email subject line
$thankyou = "thankyou.htm"; // thank you page

// if you update the question on the form -
// you need to update the questions answer below
$antispam_answer = "25";

?>