$('#templateinfo').html('<table><tr><td><em>Template: <u>mri_nrad_ms-v0.93</u> (Letze Aktualisierung: 21.12.2018)</em></td></tr><tr><td><a href="server/feedback/contactform.htm?t=mri_nrad_ms-v0.93" id="nradms_feedback" target="_blank"><em>Feedback</em></a></td></tr></table>');
$('#nradms_bef_seq_axT2KM').attr("data-value", "Axiale T1 + KM")
$('label[for=nradms_bef_seq_axT2KM]').html("Axiale T1 + KM");
$('label[for=nradms_bef_nbws_dae_ja]').html("Dorsales Alignment gestört");
$('<br><br>').insertAfter('#nradms_divbeurteilung');

<!-- ####################### --><!-- FURTHER CONTENT --><!-- ####################### -->

//$('#xx').attr("data-description", "");